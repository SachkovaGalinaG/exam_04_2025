import os
from flask import Flask
from flask_migrate import Migrate
from app.extensions import db
from app.routes import main

def create_app():
    app = Flask(__name__)
    
    # Явно указываем конфигурацию
    app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('FLASK_SQLALCHEMY_DATABASE_URI', 'sqlite:///default.db')

    # Инициализируем базу данных
    db.init_app(app)
    
    # Инициализация Flask-Migrate
    migrate = Migrate(app, db)

    # Регистрируем Blueprint для маршрутов
    app.register_blueprint(main)

    return app